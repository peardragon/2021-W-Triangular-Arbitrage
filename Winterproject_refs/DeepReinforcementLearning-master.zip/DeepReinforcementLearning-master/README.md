# DeepReinforcementLearning
A replica of the AlphaZero methodology in Python

See this article for a summary of the algorithm and run instructions.

https://adsp.ai/blog/how-to-build-your-own-alphazero-ai-using-python-and-keras/
